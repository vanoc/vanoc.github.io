# -*- coding: utf8 -*-

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
import gobject

import Image
import math
import os
import os.path
import shutil
import sys
import tempfile
import threading

import locale
import gettext
_ = gettext.gettext		

import EPL.Config
import EPL.Exception
import EPL.Video
import EPL.UI

def shellEscape(str):
	return "\"" + str.replace("\\", "\\\\").replace("\"", "\\\"").replace("$", "\\$") + "\""

def shellReplace(str):
	return str.replace("\\", "_").replace("\"", "_").replace("$", "_") \
		.replace(">", "_").replace("<", "_").replace("(", "_").replace(")", "_") \
		.replace("{", "_").replace("}", "_").replace("'", "_").replace(" ", "_") \
		.replace("&", "_").replace("|", "_").replace("~", "_")

class Widgets(gtk.glade.XML):
	def __getitem__(self, key):
		return self.get_widget(key)

class ConvertThread(threading.Thread):
	def __init__(self, parent, input, output, preset, resolution):
		# invoke constructor of parent class
		threading.Thread.__init__(self)

		self.parent = parent
		self.input = input
		self.output = output
		self.preset = preset
		self.resolution = resolution

		self.stopEvent = threading.Event()
		
		self.progressUpdater = EPL.UI.ProgressUpdater(7, \
			self.parent.updateProgressBar, \
			self.parent.updateStageLabel, \
			self.stopEvent)

	def run(self):
		gobject.idle_add(self.parent.setProgressWidgetVisible, True)

		tmpdir = tempfile.mkdtemp()

		try:
			input = self.input
			output = self.output
			width = self.resolution["width"]
			height = self.resolution["height"]
			quality = self.preset["quality"]
			fps = self.preset["fps"]
			frequency = self.preset["frequency"]
			channels = self.preset["channels"]

			movinfo = EPL.Video.Info(input)
			totalFrames = round(float(movinfo["length"]) * fps)
			mplayerLength = math.ceil(float(movinfo["length"]))

			#
			# Dump audio
			#
			self.progressUpdater.goStage(_("Extracting the audio stream..."), mplayerLength)
			cmd = "LANG=C mplayer -identify -vc null -vo null -ao pcm:fast:file=" + tmpdir
			cmd += "/audiodump.wav " + input
			cmd += r" 2>/dev/null | tr \\r \\n"
			self.progressUpdater.trackPopen(cmd, r"^A:\s+(\d+\.\d+)\s")

			#
			# Convert audio
			#
			self.progressUpdater.goStage(_("Converting the audio stream..."), 101.0)
			cmd = "LANG=C sox -S " + tmpdir + "/audiodump.wav -r " + str(frequency)
			cmd += " -c " + str(channels) + " " + tmpdir + "/frame.wav"
			cmd += r" 2>&1 | tr \\r \\n"
			self.progressUpdater.trackPopen(cmd, r"^Time:\s+[^\(]+\(\s*(\d+\.\d+)%\)\s")
			os.remove(tmpdir + "/audiodump.wav")
			self.progressUpdater.goStep(101)

			#
			# Scale video
			#
			self.progressUpdater.goStage(_("Re-scaling the video..."), 100.0)
			cmd = "LANG=C mencoder -ovc raw -ofps " + str(fps) + " -oac copy -vf scale="
			cmd += str(width) + ":-2,expand=" + str(width) + ":" + str(height) + ",format=bgr16 "
			cmd += input + " -o " + tmpdir + "/videodump.avi"
			cmd += r" 2>&1 | tr \\r \\n"
			self.progressUpdater.trackPopen(cmd, r"^Pos:\s+[^\(]+\((\d+)%\)\s")

			#
			# Extract video frames to JPEGs
			#
			self.progressUpdater.goStage(_("Extracting the video frames to JPEGs..."), mplayerLength)
			cmd = "LANG=C mplayer -nosound -vo jpeg:outdir=" + tmpdir + "/frame -xy " + str(width)
			cmd += " -zoom " + tmpdir + "/videodump.avi"
			cmd += r" 2>/dev/null | tr \\r \\n"
			self.progressUpdater.trackPopen(cmd, r"^V:\s+(\d+\.\d+)\s")

			#
			# Convert JPEGs to BMPs
			#
			list = os.listdir(tmpdir + "/frame")
			self.progressUpdater.goStage(_("Converting the JPEGs to BMPs..."), len(list))
			i = cnt = 0
			for item in list:
				split = item.split(".")
				if split[-1] == "jpg":
					im = Image.open(tmpdir + "/frame/" + item)
					im.save(tmpdir + "/frame" + split[0].lstrip("0") + ".bmp", "BMP")
					os.remove(tmpdir + "/frame/" + item)
					i += 1
				cnt += 1
				self.progressUpdater.goStep(cnt)
				if self.stopEvent.isSet():
					raise EPL.Exception.StopRequestedException()

			#
			# Create MoviePod (.mvpd) file
			#
			self.progressUpdater.goStage(_("Creating the MoviePod (.mvpd) file..."), totalFrames)
			cmd = "LANG=C mv_encoder -c -s 1 -e " + str(i)
			cmd += " -f " + tmpdir + "/frame -o " + output
			cmd += " -q " + str(quality) + " -x " + str(width) + " -y " + str(height)
			cmd += " -m " + str(1 / fps * 1000)
			cmd += r" 2>/dev/null | tr \\r \\n"
			self.progressUpdater.trackPopen(cmd, r"^Processing\sFrame\s(\d+)\s")

			#cmd = "LANG=C mv_analyzer " + output
			#os.system(cmd)
		except EPL.Exception.StopRequestedException:
			pass

		except:
			gobject.idle_add(self.parent.displayError)

		#
		# Clean up
		#
		self.progressUpdater.goStage(_("Cleaning up..."), 1)
		shutil.rmtree(tmpdir, True)

		self.progressUpdater.goStage(_("All done."))
		gobject.idle_add(self.parent.setProgressWidgetVisible, False)

	def stop(self):
		self.stopEvent.set()

class App:
	def __init__(self, siteConfigFileName):
		self.initSiteConfig(siteConfigFileName)
		self.initConfig()
		self.initLocale()

		self.widgets = Widgets(self.siteConfig.get("Paths", "glade.file"))
		self.widgets.signal_autoconnect(self)

		self.widgets["presetComboBox"].set_active(0)

		if self.config.get("iPod", "Model") == "Nano":
			pos = 0
		elif self.config.get("iPod", "Model") == "Mini":
			pos = 1
		elif self.config.get("iPod", "Model") == "Photo":
			pos = 2
		else:
			pos = 0
		self.widgets["iPodModelComboBox"].set_active(pos)

		#
		# Add filters to the file chooser 
		#

		filter = gtk.FileFilter()
		filter.set_name(_("Videos"))
		filter.add_mime_type("video/mp4v-es")
		filter.add_mime_type("video/mpeg")
		filter.add_mime_type("video/quicktime")
		filter.add_mime_type("video/x-ms-asf")
		filter.add_mime_type("video/x-ms-wmv")
		filter.add_mime_type("video/x-msvideo")
		filter.add_pattern("*.wmv")
		filter.add_pattern("*.avi")
		filter.add_pattern("*.mpeg")
		filter.add_pattern("*.mpg")
		filter.add_pattern("*.mpe")
		filter.add_pattern("*.qt")
		filter.add_pattern("*.mov")
		filter.add_pattern("*.mp4")
		filter.add_pattern("*.asf")
		filter.add_pattern("*.asx")
		self.widgets["inputFileChooser"].add_filter(filter)

		filter = gtk.FileFilter()
		filter.set_name(_("All files"))
		filter.add_pattern("*")
		self.widgets["inputFileChooser"].add_filter(filter)
		self.widgets["inputFileChooser"].set_current_folder(self.config.get("Folders", "Input"))

		self.widgets["outputFolderChooser"].set_filename(self.config.get("Folders", "Output"))

		#
		# Fix Glade's bug not specifying the image correctly...
		#
		self.widgets["leftImage"].set_from_file(self.siteConfig.get("Paths", "ipod.svg"));

		self.worker = None

	def initConfig(self):
		CONFIG_DIR  = os.path.expanduser("~/.mvpdmake/")
		if not os.path.isdir(CONFIG_DIR):
			os.makedirs(CONFIG_DIR)

		CONFIG_FILE  = os.path.join(CONFIG_DIR, "config")

		initial = {
			"Folders":
			{
				"Input": os.path.expanduser("~/Desktop"),
				"Output": os.path.expanduser("~/Desktop"),
			},

			"iPod":
			{
				"Model": "Nano",
			}
		}
		
		self.config = EPL.Config.Config(CONFIG_FILE, initial)		
	
	def initSiteConfig(self, fileName):
		self.siteConfig = EPL.Config.Config(fileName)		
	
	def initLocale(self):
		locale.setlocale(locale.LC_ALL, '')
		gettext.bindtextdomain("mvpdmake", self.siteConfig.get("Paths", "intl-mo-dir"))
		gettext.textdomain("mvpdmake")
		gettext.install("mvpdmake", self.siteConfig.get("Paths", "intl-mo-dir"), unicode = 1)
		gtk.glade.bindtextdomain("mvpdmake", self.siteConfig.get("Paths", "intl-mo-dir"))
		gtk.glade.textdomain("mvpdmake")

	def main(self):
		gobject.threads_init()
		gtk.gdk.threads_init()
		gtk.main()

	def onQuit(self, widget, data=None):
		self.config.write()
		gtk.main_quit()

	def onAbout(self, widget, data=None):
		self.widgets["aboutDialog"].show()

	def onConvert(self, widget, data=None):
		#
		# Check if the user specified both the input and the output files...
		#
		inputFileName = self.widgets["inputFileChooser"].get_filename()
		if inputFileName == None:
			errorDialog = gtk.MessageDialog(parent = self.widgets["mainWindow"], 
				type = gtk.MESSAGE_ERROR,
				buttons = gtk.BUTTONS_CLOSE)
			errorDialog.set_markup(_("<big>No input file selected...</big>\n\n" \
				"You should select an input video file\nthat you want to convert."))
			response = errorDialog.run()
			errorDialog.destroy()
			return
		inputFileName = shellEscape(inputFileName)

		outputFileName = self.widgets["outputFileNameEntry"].get_text().strip()
		if outputFileName == "":
			errorDialog = gtk.MessageDialog(parent = self.widgets["mainWindow"], 
				type = gtk.MESSAGE_ERROR,
				buttons = gtk.BUTTONS_CLOSE)
			errorDialog.set_markup(_("<big>Output file name missing...</big>\n\n" \
					"You should provide a file name\nthat you want to save the\n" \
					"converted video under."))
			response = errorDialog.run()
			errorDialog.destroy()
			return

		#
		# Construct the output file name
		#
		outputFolderName = self.widgets["outputFolderChooser"].get_filename()
		assert(outputFolderName != None)
		outputFileName = shellEscape(outputFolderName + "/" + 
			os.path.splitext(os.path.split(inputFileName)[1])[0] + ".mvpd")

		#
		# Obtain the desired preset and start converting...
		#
		preset = self.getPreset(self.widgets["presetComboBox"].get_active())
		resolution = self.getResolution(self.widgets["iPodModelComboBox"].get_active())
	
		self.worker = ConvertThread(self, inputFileName, outputFileName, preset, resolution)
		self.worker.start()

	def getPreset(self, index):
		if index == 0:
			return { "quality":10, "fps":float(10), "frequency":44100, "channels":2 }
		elif index == 1:
			return { "quality":15, "fps":float(8), "frequency":24000, "channels":1 }
		elif index == 2:
			return { "quality":15, "fps":float(10), "frequency":24000, "channels":2 }
		else:
			return { "quality":17, "fps":float(8), "frequency":16000, "channels":1 }

	def getResolution(self, index):
		if index == 0:
			return { "width":176, "height":132 }
		elif index == 1:
			return { "width":138, "height":110 }
		elif index == 2:
			return { "width":220, "height":176 }
		else:
			raise NotImplementedError()

	def onDeleteEvent(self, widget, data=None):
		widget.hide()
		return True

	def onStopButton(self, widget, data=None):
		assert(self.worker != None)
		self.worker.stop()
		self.worker.join()
		self.worker = None

	def updateStageLabel(self, stage):
		self.widgets["progressBar"].set_text(stage)

	def updateProgressBar(self, fraction=None, text=None):
		self.widgets["progressBar"].set_fraction(fraction)

	def setProgressWidgetVisible(self, visible):
		if visible:
			self.widgets["progressBar"].show()
			self.widgets["stopButton"].show()
		else:
			self.widgets["progressBar"].hide()
			self.widgets["stopButton"].hide()

		self.widgets["convertButton"].set_sensitive(not visible)
		self.widgets["inputFileChooser"].set_sensitive(not visible)
		self.widgets["outputFileNameEntry"].set_sensitive(not visible)
		self.widgets["outputFolderChooser"].set_sensitive(not visible)
		self.widgets["presetComboBox"].set_sensitive(not visible)
		self.widgets["iPodModelComboBox"].set_sensitive(not visible)
		
	def dialogResponseCB(self, dialog, responseID):
		dialog.destroy()

		if responseID == gtk.RESPONSE_OK:
			pass

	def dialogRun(self, dialog):
		if not dialog.modal:
			dialog.set_modal(True)
		dialog.connect('response', self.dialogResponseCB)
		dialog.show()

	def displayError(self):
		dialog = gtk.MessageDialog(parent = self.widgets["mainWindow"], 
			type = gtk.MESSAGE_ERROR,
			message_format = _("An error occured preventing the\nconversion from completion... ;("),
			buttons = gtk.BUTTONS_CLOSE)
		self.dialogRun(dialog)
		
	def onInputFileActivated(self, widget, data=None):
		#
		# Don't reset the text the user may have entered in the field...
		#
		if self.widgets["outputFileNameEntry"].get_text().strip() != "":
			return
			
		inputFileName = self.widgets["inputFileChooser"].get_filename()
		if inputFileName != None:
			outputFileName = os.path.splitext(os.path.split(inputFileName)[1])[0] + ".mvpd"
			self.widgets["outputFileNameEntry"].set_text(shellReplace(outputFileName))

		currentFolder = self.widgets["inputFileChooser"].get_current_folder()
		self.config.set("Folders", "Input", currentFolder)

	def onOutputFolderActivated(self, widget, data=None):
		currentFolder = self.widgets["outputFolderChooser"].get_current_folder()
		self.config.set("Folders", "Output", currentFolder)

	def on_iPodModelComboBox_changed(self, widget, data=None):
		pos = self.widgets["iPodModelComboBox"].get_active()
		model = "Nano"
		if pos == 0:
			model = "Nano"
		elif pos == 1:
			model = "Mini"
		elif pos == 2:
			model = "Photo"
		self.config.set("iPod", "Model", model)

if __name__ == "__main__":
	if len(sys.argv) > 1:                                                                                 
		app = App(sys.argv[1])
		app.main()
	else:
		print "Usage: MvpdMake.py <site-config-filename>"

