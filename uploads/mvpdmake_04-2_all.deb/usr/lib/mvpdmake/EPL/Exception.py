# -*- coding: utf8 -*-

import exceptions

class StopRequestedException(exceptions.Exception):

	def __init__(self):
		pass

