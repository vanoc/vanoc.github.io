# -*- coding: utf8 -*-

import gettext
_ = gettext.gettext

import gobject
import os
import re

import Exception

class ProgressUpdater:
	def __init__(self, numStages, barUpdateFunc, stageUpdateFunc, stopEvent):
		self.numStages = numStages
		self.barUpdateFunc = barUpdateFunc
		self.stageUpdateFunc = stageUpdateFunc
		self.stopEvent = stopEvent

		self.curStageNum = -1
		self.curStageSteps = 0.0
		self.curStagePos = 0.0
		self.stageDelta = 1.0 / numStages
		self.stepDelta = 0.0

		self.updateBar(0)
		self.updateLabel(_("Initializing..."))

	def updateBar(self, pos):
		gobject.idle_add(self.barUpdateFunc, pos)

	def updateLabel(self, text):
		gobject.idle_add(self.stageUpdateFunc, text)

	def goStage(self, label, steps = 1):
		self.curStageNum += 1
		if self.curStageNum < self.numStages:
			self.curStageSteps = steps
			self.stepDelta = self.stageDelta / steps
			self.curStagePos = self.stageDelta * self.curStageNum
			self.updateBar(self.curStagePos)
			self.updateLabel(label)
		elif self.curStageNum == self.numStages:
			self.curStageSteps = 0
			self.stepDelta = 0
			self.curStagePos = 1.0
			self.updateBar(self.curStagePos)
			self.updateLabel(label)
		else:
			raise IndexError("Expected stages: " + self.numStages + \
					"Got transition to stage: " + self.curStageNum)

	def goStep(self, num):
		if num > self.curStageSteps:
			num = self.curStageSteps
		self.updateBar(self.curStagePos + self.stepDelta * num)

	def trackPopen(self, cmd, expr, debug = False):
		fin = os.popen(cmd, "r", 0)
		for curLine in fin:
			if not self.stopEvent.isSet():
				m = re.match(expr, curLine)
				if m:
					self.goStep(float(m.group(1)))
				elif debug:
					print "EPL.UI.trackPopen.LINE:", curLine
		fin.close()
		if self.stopEvent.isSet():
			raise Exception.StopRequestedException()


