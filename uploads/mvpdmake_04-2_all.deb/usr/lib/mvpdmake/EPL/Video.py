# -*- coding: utf8 -*-

import os

class Info:
	#{
	# 'ID_VIDEO_WIDTH': '320', 
	# 'ID_AUDIO_NCH': '2', 
	# 'ID_VIDEO_FPS': '24.998', 
	# 'ID_VIDEO_BITRATE': '649712', 
	# 'ID_FILENAME': '/media/EPL200HD/ftp/pub/Videos/Music\\ Clips/Avril\\ Lavigne\\ -Sk8er\\ Boi\\ .avi', 
	# 'ID_DEMUXER': 'avi', 
	# 'ID_VIDEO_ASPECT': '0.0000', 
	# 'ID_AUDIO_BITRATE': '1024000', 
	# 'ID_LENGTH': '161.89', 
	# 'ID_VIDEO_FORMAT': 'DX50', 
	# 'ID_AUDIO_CODEC': 'pcm', 
	# 'ID_AUDIO_ID': '1', 
	# 'ID_AUDIO_FORMAT': '1', 
	# 'ID_VIDEO_HEIGHT': '240', 
	# 'ID_VIDEO_ID': '0', 
	# 'ID_AUDIO_RATE': '32000', 
	# 'ID_VIDEO_CODEC': 'ffodivx'
	#}

	def __init__(self, filename):
		fin = os.popen("LANG=C midentify " + filename, "r", 0)
		self.movinfo = {}
		for line in fin:
			key, value = line.strip().split("=", 1)
			self.movinfo[key] = value
		fin.close()

	def __getitem__(self, key):
		return self.movinfo["ID_" + key.upper().replace(" ", "_")]

