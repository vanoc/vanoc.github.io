###
#
# Based on the config.py found in the Listen music player code.
#
# Listen is the legal property of mehdi abaakouk <theli48@gmail.com>
# Copyright (c) 2006 Mehdi Abaakouk
#
###


# Simple proxy to a Python ConfigParser.
import os
import gtk

# We don't need/want variable interpolation.
from ConfigParser import RawConfigParser as ConfigParser

class Config:
	def __init__(self, filename, initial=None):
		self._config = ConfigParser()

		self.get = self._config.get
		self.getBoolean = self._config.getboolean
		self.getInt = self._config.getint
		self.getFloat = self._config.getfloat
		self.options = self._config.options
		
		if initial:
			for section, values in initial.iteritems():
				self._config.add_section(section)
				for key, value in values.iteritems():
					self._config.set(section, key, value)

		self.filename = filename
		self._config.read(self.filename)
    
	def set(self, section, option, value):
	    self._config.set(section, option, value)

	def write(self):
		if not os.path.isdir(os.path.dirname(self.filename)):
			os.makedirs(os.path.dirname(self.filename))
		f = file(self.filename, "w")
		self._config.write(f)
		f.close()

